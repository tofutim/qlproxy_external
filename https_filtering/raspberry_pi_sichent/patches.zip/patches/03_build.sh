#!/bin/bash

# setup some variables
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# bail out on any error
set -e

# install build tools
apt-get -y install devscripts build-essential fakeroot libssl-dev pkg-config

# fetch the source for the package to re-build from the jessy repositories
echo "Copying sources lists..."
cp /etc/apt/sources.list /etc/apt/sources.list.default
cp /etc/apt/sources.list /etc/apt/sources.list.jessy
cp /etc/apt/sources.list /etc/apt/sources.list.wheezy

echo "Adding source repositories..."
echo "deb-src http://archive.raspbian.org/raspbian jessie main contrib non-free" >> /etc/apt/sources.list.jessy
echo "deb-src http://archive.raspbian.org/raspbian wheezy main contrib non-free" >> /etc/apt/sources.list.wheezy

echo "Getting Squid from Jessy..."
cp /etc/apt/sources.list.jessy /etc/apt/sources.list
apt-get update
apt-get source squid3=3.3.8-1.1 --download-only
apt-get source libecap2=0.2.0-1 --download-only

echo "Getting Squid dependencies from Wheezy..."
cp /etc/apt/sources.list.wheezy /etc/apt/sources.list
apt-get update
apt-get build-dep squid3

echo "Reverting default repository..."
mv /etc/apt/sources.list.default /etc/apt/sources.list
apt-get update

# run dpkg-source on dsc file
echo "Running dpkg-source..."
dpkg-source -x squid3_3.3.8-1.1.dsc
dpkg-source -x libecap_0.2.0-1.dsc

# build libecap2
echo "Building libecap2..."
pushd libecap-0.2.0
dpkg-buildpackage -rfakeroot -b
popd

# install libecap2 and libecap2-dev we have just built
echo "Installing libecap2..."
dpkg --install *.deb

# cd into source directory 
pushd squid3-3.3.8

# modify configure options in debian/rules, add --enable-ssl --enable-ssl-crtd
echo "Patching Squid source..."
patch debian/rules < "$DIR/rules.patch"
patch debian/control < "$DIR/control.patch"
patch src/ssl/gadgets.cc < "$DIR/gadgets.cc.patch"

# build the package
echo "Building Squid..."
#dpkg-buildpackage -rfakeroot -b
popd

echo "SUCCESS!"
#!/bin/bash

# setup some variables
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# bail out on any error
set -e

# get qlproxy
wget http://updates.diladele.com/qlproxy/binaries/3.0.0.3E4A/armhf/release/rpi/qlproxy-3.0.0.3E4A_armhf.deb

# install it
dpkg --install qlproxy-3.0.0.3E4A_armhf.deb

# disable apache2 default web site
a2dissite 000-default

# enable qlproxy site
a2ensite qlproxy.conf

# restart apache
service apache2 restart

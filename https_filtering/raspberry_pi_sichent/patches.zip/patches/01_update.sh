#!/bin/bash
set -e
apt-get update && apt-get upgrade && reboot

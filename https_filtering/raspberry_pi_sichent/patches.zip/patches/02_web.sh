#!/bin/bash
set -e
apt-get install python-setuptools 
easy_install django==1.5
apt-get install apache2 libapache2-mod-wsgi

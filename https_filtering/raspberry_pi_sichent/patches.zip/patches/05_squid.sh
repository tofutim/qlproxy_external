#!/bin/bash

# setup some variables
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# bail out on any error
set -e

# install some more required packages
apt-get install ssl-cert
apt-get install squid-langpack

# install our recompiled packages
dpkg --install squid3-common_3.3.8-1.1_all.deb
dpkg --install squid3_3.3.8-1.1_armhf.deb
dpkg --install squidclient_3.3.8-1.1_armhf.deb

# normally not needed (uncomment if you need these)
# sudo dpkg --install squid-cgi_3.3.8-1.1_armhf.deb
# sudo dpkg dpkg --install squid3-dbg_3.3.8-1.1_armhf.deb
# sudo dpkg dpkg --install squid-purge_3.3.8-1.1_armhf.deb

# set up the ssl_crtd daemon
ln -s /usr/lib/squid3/ssl_crtd /bin/ssl_crtd
/bin/ssl_crtd -c -s /var/spool/squid3_ssldb
chown -R proxy:proxy /var/spool/squid3_ssldb

# modify squid.conf file to enable HTTPS bumping
cp /etc/squid3/squid.conf /etc/squid3/squid.conf.default
patch /etc/squid3/squid.conf < "$DIR/squid.conf.patch"
/usr/sbin/squid3 -k parse

# uncomment to regenerate certificates for SSL bumping if you do not like defaults
# openssl req -new -newkey rsa:1024 -days 1365 -nodes -x509 -keyout myca.pem  -out myca.pem
# openssl x509 -in myca.pem -outform DER -out myca.der
# then copy certificates 
# cp "$DIR/myca.pem" /etc/opt/quintolabs/qlproxy/
# cp "$DIR/myca.der" /etc/opt/quintolabs/qlproxy/

# stop all services
service squid3 stop
service apache2 stop
/etc/init.d/qlproxy stop

# adjust squid make it dependent on qlproxy
cp squid3 /etc/insserv/overrides/
insserv -v -d 2>&1

# and start
/etc/init.d/qlproxy start
service squid3 start
service apache2 start

echo "OK!"

#!/bin/bash
set -e

# all web packages are installed as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# install python libs
yum install python-setuptools python-ldap

# install python django for web ui
easy_install django==1.5

# install apache web server to run web ui
yum install httpd php mod_wsgi

# make apache autostart on reboot
chkconfig httpd on

# this fixes some apache errors when working with python-django wsgi
echo "WSGISocketPrefix /var/run/wsgi" >> /etc/httpd/conf.d/wsgi.conf

# and restart apache
service httpd restart

echo "Web requirements installed correctly!"

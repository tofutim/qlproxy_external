#!/bin/bash

# stop on every error
set -e

# install RPMs as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# detect current architecture (default assumes x86_64)
ARCH_1=`uname -m`
ARCH_2="amd64"
ARCH_3="lib64"

if [[ $ARCH_1 == 'i686' ]]; then
	ARCH_2="i386"
	ARCH_3="lib"
fi

pushd rpmbuild/RPMS/$ARCH_1
yum localinstall -y squid-3.4.4-0.el6.$ARCH_1.rpm
popd

# set up the ssl_crtd daemon
if [ -f /bin/ssl_crtd ]; then
	rm -f /bin/ssl_crtd
fi

ln -s /usr/$ARCH_3/squid/ssl_crtd /bin/ssl_crtd
/bin/ssl_crtd -c -s /var/spool/squid_ssldb
chown -R squid:squid /var/spool/squid_ssldb

# uncomment to regenerate certificates for SSL bumping if you do not like defaults
# openssl req -new -newkey rsa:1024 -days 1365 -nodes -x509 -keyout myca.pem  -out myca.pem
# openssl x509 -in myca.pem -outform DER -out myca.der
# then copy certificates 
# cp myca.pem /etc/opt/quintolabs/qlproxy/
# cp myca.der /etc/opt/quintolabs/qlproxy/

# make squid autostart after reboot
chkconfig squid on

echo "Squid RPM is installed successfully"

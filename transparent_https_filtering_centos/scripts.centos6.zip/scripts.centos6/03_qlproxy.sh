#!/bin/bash

# all packages are installed as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# detect current architecture (default assumes x86_64)
ARCH_1=`uname -m`
ARCH_2="amd64"
if [[ $ARCH_1 == 'i686' ]]; then
	ARCH_1="i386"
	ARCH_2="i386"
fi

# bail out on any error
set -e

# get latest qlproxy
curl http://updates.diladele.com/qlproxy/binaries/3.2.0.4CAF/$ARCH_2/release/centos6/qlproxy-3.2.0-4CAF.$ARCH_1.rpm > qlproxy-3.2.0-4CAF.$ARCH_1.rpm

# install it
yum -y --nogpgcheck localinstall qlproxy-3.2.0-4CAF.$ARCH_1.rpm
  
# qlproxy installed everything needed for apache, so just restart
service httpd restart

echo "Diladele Web Safety is installed!"
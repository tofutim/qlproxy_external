#!/bin/bash

# stop on any error
set -e

# rpm build MUST be run as normal user
if [[ $EUID -eq 0 ]]; then
   echo "This script must NOT be run as root" 1>&2
   exit 1
fi

# get squid sources
pushd rpmbuild/SOURCES
curl http://www.squid-cache.org/Versions/v3/3.4/squid-3.4.4.tar.xz > squid-3.4.4.tar.xz
curl http://www.squid-cache.org/Versions/v3/3.4/squid-3.4.4.tar.xz.asc > squid-3.4.4.tar.xz.asc
popd

# build the binaries RPMs out of sources
pushd rpmbuild/SPECS
rpmbuild -v -bb squid.spec
popd

echo "RPM built successfully."

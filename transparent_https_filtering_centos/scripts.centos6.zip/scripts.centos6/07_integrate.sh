#!/bin/bash

# stop on any error
set -e

# integration should be done as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi

# allow web ui read-only access to squid configuration file
chmod o+r /etc/squid/squid.conf

# perform integration by replacing squid.conf file
mv /etc/squid/squid.conf /etc/squid/squid.conf.original && mv squid.conf /etc/squid/squid.conf

# parse the resulting config just to be sure
/usr/sbin/squid -k parse

# restart squid to load all config
/sbin/service squid restart

echo "squid integrated with Diladele Web Safety"